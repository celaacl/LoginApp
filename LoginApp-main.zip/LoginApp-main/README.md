![Screenshot_20230128_171541](https://user-images.githubusercontent.com/101534144/215261282-a9d5dd5f-3480-4f6b-aab0-8faee86052ae.png)
![CardView](https://user-images.githubusercontent.com/101534144/222365128-a85ba423-7483-4c48-a497-a35c192e8198.jpg)
![Grid](https://user-images.githubusercontent.com/101534144/222365142-dfc44359-c52c-4d15-9db7-d019e5b403a5.jpg)
