package com.example.ukl

data class Product (
    var name: String = " ",
    var harga: String = " ",
    var photo: String = " "
)
